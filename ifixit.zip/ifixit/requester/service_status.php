<?php
    session_start();
    define('PAGE', 'profile');
    include('../dbConnection.php');
    include('includes/header.php');
    if($_SESSION['is_login']){
        $lemail = $_SESSION['lemail'];
    }
    else{
        header("location:user_login.php");
}
?>

<div class="col-lg-6 col-sm-6">
    <form action="" method="post">
        <div class="form-group">
            <label for="checkid">Enter Request ID:</label>
            <input type="text" class="form-control" name="checkid" id="checkid" required>
        </div>
        <button type="submit" class="btn btn-danger" name="search">Search</button>
    </form>

    <?php 
        if(isset($_POST['search']))
        {
            $q=mysqli_query($con, "select * from assign_work where r_id = {$_POST['checkid']}");
            
            $arr = mysqli_fetch_array($q);

           if($arr[1] == $_POST['checkid']){
        
    ?>
<h3 class="text-center"><b>Assigned work Details</b></h3>
    <table class="table table-bordered mt-5">
        <tr>
            <th>Requet ID</th>
            <td><?php if(isset($arr[1])){echo $arr[1];} ?></td>
        </tr>
        <tr>
            <th>Requet info</th>
            <td><?php if(isset($arr[2])){echo $arr[2];} ?></td>
        </tr>
        <tr>
            <th>Requet Description</th>
            <td><?php if(isset($arr[3])){echo $arr[3];} ?></td>
        </tr>
        <tr>
            <th>Name</th>
            <td><?php if(isset($arr[4])){echo $arr[4];} ?></td>
        </tr>
        <tr>
            <th>Address Line1</th>
            <td><?php if(isset($arr[5])){echo $arr[5];} ?></td>
        </tr>
        <tr>
            <th>Address Line2</th>
            <td><?php if(isset($arr[6])){echo $arr[6];} ?></td>
        </tr>
        <tr>
            <th>City</th>
            <td><?php if(isset($arr[7])){echo $arr[7];} ?></td>
        </tr>
        <tr>
            <th>State</th>
            <td><?php if(isset($arr[8])){echo $arr[8];} ?></td>
        </tr>
        <tr>
            <th>Zip</th>
            <td><?php if(isset($arr[9])){echo $arr[9];} ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?php if(isset($arr[10])){echo $arr[10];} ?></td>
        </tr>
        <tr>
            <th>Mobile</th>
            <td><?php if(isset($arr[11])){echo $arr[11];} ?></td>
        </tr>
        <tr>
            <th>Technician Name</th>
            <td><?php if(isset($arr[12])){echo $arr[12];} ?></td>
        </tr>
        <tr>
            <th>Assigned Date</th>
            <td><?php if(isset($arr[13])){echo $arr[13];} ?></td>
        </tr>
        <tr>
            <th>Customer Sign</th>
            <td></td>
        </tr>
        <tr>
            <th>Technician Sign</th>
            <td></td>
        </tr>
    </table>
    <?php }
    else{
        echo "<div class='alert alert-warning mt-5'>Your Request is still Pendding</div>";
    }
}
    ?>
</div>



<?php
    include('includes/footer.php');
?>