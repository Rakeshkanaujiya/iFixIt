<?php
    session_start();
    define('PAGE', 'profile');
    include('../dbConnection.php');
    include('includes/header.php');
    if($_SESSION['is_login']){
        $lemail = $_SESSION['lemail'];
    }
    else{
        header("location:user_login.php");
    }

    $q=mysqli_query($con, "select * from user_login where r_email = '$lemail'");

    if($row = mysqli_num_rows($q)>0)
    {
        $r=mysqli_fetch_array($q);
        $rname=$r['r_name'];
        $r2mobile=$r['r_mobile'];
        $remail=$r['r_email'];
        $rpass=$r['r_pass'];
        
    }
    
    if(isset($_POST['sub']))
    {
        $rmobile=$_REQUEST['rmobile'];
        $q=mysqli_query($con, "update user_login set r_mobile = '$rmobile' where r_email = '$remail'");
        if($q)
        {
            echo "<script>alert('Update Successfully');</script>";
            
        }
    }
?>              
            <div class="col-lg-6 col-md-6 col-sm-8 col-xs-8 my-5">

                <form action="" method="post" >
                    <div class="form-group">
                        <label for="">Email</label><input type="email" class="form-control" name="remail" value="<?php echo $remail; ?>" id="" readonly>
                    </div>
                    <div class="form-group">
                        <label for="">Mobile No.</label><input type="text" class="form-control" value="<?php echo $r2mobile; ?>"  name="rmobile" >
                    </div>
                    <div class="form-group">
                    <input type="submit" value="Update" class="btn btn-danger" name="sub">
                    </div>
                </form>
            </div>

<?php
    include('includes/footer.php');
?>