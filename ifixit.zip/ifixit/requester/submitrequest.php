<?php
    session_start();
    include('includes/header.php');
    include('../dbConnection.php');
    if($_SESSION['is_login']){
        $lemail = $_SESSION['lemail'];
    }
    else{
        header("location:user_login.php");
    }
    if(isset($_POST['sub']))
    {
        $request=$_POST['request'];
        $desc=$_POST['desc'];
        $name=$_POST['name'];
        $add1=$_POST['add_line1'];
        $add2=$_POST['add_line2'];
        $city=$_POST['city'];
        $state=$_POST['state'];
        $zip=$_POST['zip'];
        $email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $date=$_POST['date'];
        $q=mysqli_query($con, "INSERT INTO `request_info` VALUES ('','$request','$desc','$name','$add1','$add2','$city','$state','$zip','$email','$mobile','$date')");
        if($q){
           
            $genid  = mysqli_insert_id($con);
            $_SESSION['myid'] = $genid;
            header('location:print.php');
        }
    }

?>
 <div class="col-lg-9 col-md-8 col-sm-8 col-xs-8 my-5">

<form action="" method="post" >
   <div class="row"><!--1st Row -->
   <div class="form-group col-lg-12">
        <label for="">Request Info</label><input type="text" class="form-control" name="request" placeholder="Request Info" required>
    </div>
    <div class="form-group col-lg-12">
        <label for="">Description</label><input type="text" class="form-control" name="desc" placeholder="Write Description" required>
    </div>
    <div class="form-group col-lg-12">
        <label for="">Name</label><input type="text" class="form-control" name="name" placeholder="Rahul" required>
    </div>
    <div class="row col-lg-12"><!--1sr Sub Row -->
        <div class="form-group col-lg-6">
            <label for="">Address Line 1</label><input type="text" class="form-control" name="add_line1" placeholder="House no." required>
        </div>
        <div class="form-group col-lg-6">
            <label for="">Address Line 1</label><input type="text" class="form-control" name="add_line2" placeholder="Railway colony" required>
        </div>
    </div>

    <div class="row col-lg-12"><!--2nd Sub Row -->
        <div class="form-group col-lg-6">
            <label for="">City</label><input type="text" class="form-control" name="city" required>
        </div>
        <div class="form-group col-lg-4">
            <label for="">State</label><input type="text" class="form-control" name="state" required>
        </div>
        <div class="form-group col-lg-2">
            <label for="">Zip</label><input type="text" class="form-control" name="zip" required>
        </div>
    </div>
    <div class="row col-lg-12"><!--3rd Sub Row -->
        <div class="form-group col-lg-5">
            <label for="">Email</label><input type="email" class="form-control" name="email" required>
        </div>
        <div class="form-group col-lg-4">
            <label for="">Mobile</label><input type="number" class="form-control" name="mobile" required>
        </div>
        <div class="form-group col-lg-3">
            <label for="">Date</label><input type="date" class="form-control" name="date" required>
        </div>
    </div>
   
    <div class="form-group col-lg-12">
        <input type="submit" value="Submit" class="btn btn-danger" name="sub">
        <input type="reset" value="Reset" class="btn btn-secondary">
    </div>
   </div>
</form>
</div>
<?php
    include('includes/footer.php');
?>