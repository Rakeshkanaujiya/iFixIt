<?php
    session_start();
    include('../dbConnection.php');
    include('includes/header.php');
    if($_SESSION['is_login']){
        $lemail = $_SESSION['lemail'];
    }
    else{
        header("location:user_login.php");
    }
    $id=$_SESSION['myid'];
    $q=mysqli_query($con, "select * from request_info where id = '$id'");

    $arr=mysqli_fetch_array($q);
?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Document</title>
     <style>
         @media print{
             #sidebar{display:none;}
             #navbar2{display:block;}
         }
     </style>
 </head>
 <body>
 <div class="col-lg-6 col-md-6 col-sm-8 col-xs-8 my-">


<table class="table table-hover ">
    <tr>
        <th>Request ID</th>
        <td><?php echo $arr['id']; ?></td>
    </tr>
    <tr>
        <th>Name</th>
        <td><?php echo $arr['name']; ?></td>
    </tr>
    <tr>
        <th>Request Info</th>
        <td><?php echo $arr['request']; ?></td>
    </tr>
    <tr>
        <th>Addre</th>
        <td><?php echo $arr['add_line1']," ".$arr['add_line2']," ".$arr['city'],"-".$arr['zip']; ?></td>
    </tr>
    <tr>
        <th>Mobile No.</th>
        <td><?php echo $arr['mobile']; ?></td>
    </tr>
    
</table>
<form action="">
    <input id="sidebar" type="submit" class="btn btn-danger" value="Print" onclick="window.print()">

</form>
</div>
 </body>
 </html>
<?php
    include('includes/footer.php');
?>