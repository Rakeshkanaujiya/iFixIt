<?php
include('../dbConnection.php');
session_start();
if(!isset($_SESSION['is_login']))
{
    if(isset($_POST['lsub']))
    {
        $lemail=$_POST['lemail'];
        $lpass=$_POST['lpass'];
   
        $q=mysqli_query($con, "select r_email from user_login where r_email = '$lemail' and r_pass = '$lpass' limit 1");
        $num=mysqli_num_rows($q);
        if($num > 0)
        {
            $_SESSION['is_login'] = true;
            $_SESSION['lemail'] = $lemail;
            header('location:welcom.php');
            exit;
        }
        else
        {
            $msg = "<div class='alert alert-danger mt-2 text-center'>Wrong user Id or password</div>";
        }
    }
}
else
{
    header('location:welcom.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Bootstrap CSS-->
    <link rel="stylesheet" href="../css/bootstrap5.css">
   

    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="../css/all.min.css">

    <!--Style CSS-->
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <title>Document</title>
    <script src="../js/script.js"></script>
</head>
<body>
<div class="container pt-5" id="registration">
        <h2 class="text-center">LogIn Into iFixIt</h2>
        <p class="text-center fw-bold"><i class="fas fa-user-secret text-danger"></i> User Login</p>
        <div class="row justify-content-center">
        <div style="margin-right;" class="col-md-5">
            <form action="" method="post" class="shadow-lg p-5">
                
                <div class="form-group">
                    <i class="fas fa-user mx-2"></i> <lable style=" font-weight: bold;">Email</lable>
                    <input type="email" name="lemail" class="form-control mt-2" placeholder="Enter your name" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-key mx-2"></i> <lable style=" font-weight: bold;">Password</lable>
                    <input type="password" name="lpass" class="form-control mt-2" placeholder="Enter Password" required>
                </div>
                <small>We will never share your email id or password with anyone</small>
                <div class="form-group d-grid">
                    <input type="submit" name="lsub" class="btn bg-success mt-3 text-white" value="Submit" placeholder="Enter your name">
                </div>
                <a href="../index.php" class="btn bg-primary text-white mt-2">Back to Home</a>
                <div>
                    <?php if(isset($msg)){ echo $msg;}?>
                </div>
            </form>
        </div>
        </div>

    <script src="../js/script.js"></script>
    <script src="../js/jquery.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/bootstrap.js"></script>
    <script src="../js/all.min.js"></script>
    </div>
</body>
</html>

