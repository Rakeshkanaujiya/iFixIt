<?php

include('dbConnection.php');


if(isset($_POST['rsub']))
{
    $q = mysqli_query($con, "select r_email from user_login where r_email = '".$_POST['remail']."'") or die("Query Failed");
    $row = mysqli_num_rows($q);
    /*echo "<pre>";
    print_r($q);
    echo "</pre>";*/
    if($row > 0)
    {
        $msg = "<div class='alert alert-danger text-center'>Account Already exists</div>";
    }
    else
    {
        $rname=$_POST['rname'];
        $rmobile=$_POST['rmobile'];
        $remail=$_POST['remail'];
        $rpass=$_POST['rpass'];
        $q=mysqli_query($con, "INSERT INTO `user_login` VALUES ('','$rname','$rmobile','$remail','$rpass')");
        if($q)
        {
            $msg = "<div class='alert alert-success text-center'>Account Created successful</div>";
           
        }
    }
}


      
?>


<div class="container pt-5" id="registration">
        <h2 class="text-center">Create an Account</h2>
        <div class="row mt-4 mb-4"></div>
        <div class="col-md-6 offset-md-3">
            <form action="" method="post" class="shadow-lg p-5">
                <div class="form-group">
                    <i class="fas fa-user mx-2"></i> <lable style=" font-weight: bold;">Name</lable>
                    <input type="text" name="rname" class="form-control" placeholder="Enter your name" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-phone-alt mx-2"></i> <lable style=" font-weight: bold;">Mobile No.</lable>
                    <input type="number" name="rmobile" class="form-control" placeholder="Enter Mobile Number" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-user mx-2"></i> <lable style=" font-weight: bold;">Email</lable>
                    <input type="email" name="remail" class="form-control" placeholder="Enter your name" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-key mx-2"></i> <lable style=" font-weight: bold;">Password</lable>
                    <input type="password" name="rpass" class="form-control" placeholder="Enter Password" required>
                </div>
                <small>We will never share your email id or password with anyone</small>
                <div class="form-group">
                    <input type="submit" name="rsub" class="btn btn-block bg-success mt-3 text-white" value="Submit">
                </div>
                <div>
                    <?php if(isset($msg)){ echo $msg;}?>
                </div>
            </form>
        </div>
    </div>
