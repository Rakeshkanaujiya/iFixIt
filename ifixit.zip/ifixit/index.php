<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
    .back-image{
    background-image:linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5));
    background-size: cover;
    min-height: 90vh;
    background-position: center center;
    background-repeat:no-repeat;
    margin-top:px;
    background-attachment: fixed;

    }

    #myMenu .navbar-nav li a{
        font-size:22px;
        font-weight:bold;
        color:coral;
    }
    #myMenu .navbar-nav li a:hover{
        color:gray;
    }
    </style>
    <!--Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap5.css">

    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
   

    <!--Style CSS-->
    <link rel="stylesheet" href="css/style.css">

    <!--Google font-->
    <title>ifixit</title>
</head>
<body>
    <!-- Start Navigation-->
    <nav class="navbar navbar-expand-sm mb-5 fixed-top" style="bordr-radius:0px;">
    <a href="index.php" id="brand" class="navbar-brand font-weight-bold text-warning"><font size="6">iFixIt</font></a>

    <button type="button" class="navbar-toggler " data-toggle="collapse" data-target="#myMenu">
    <span class="navbar-toggler-icon text-center font-weight-bold mr-3 mt-2">Click</span>
    </button>
    <div class="collapse navbar-collapse" id="myMenu">
        <ul class="navbar-nav pl-5" style="margin-left:50%;">
            <LI class="nav-item"><a href="" class="nav-link">Home</a></LI>
            <LI class="nav-item"><a href="#service" class="nav-link">Service</a></LI>
            <LI class="nav-item"><a href="#registration" class="nav-link">Registration</a></LI>
            <LI class="nav-item"><a href="requester/user_login.php" class="nav-link">Login</a></LI>
            <LI class="nav-item"><a href="#contact_us" class="nav-link">Contact</a></LI>
        </ul>
    </div>
    </nav>
   
    <!-- Start Background Header-->
    <header class=" back-image" style="background-image:url('img/banner2.jpg'); ">
        <!--<div class="p-5" >
            <h1 id="wel" class="text-primary font-weight-bold mb-4 text-uppercase">Welcom to iFixIt</h1>
            <p class="text-white mb-4 font-italic">Customer's Happiness is our Aim</p>
            <a href="user_login.php" class="btn btn-success ">Login</a>
            <a href="" class="btn btn-danger ml-4">Sign Up</a>
        </div>-->
        
    </header>
    <!-- Start Services -->

    <div class="container" id="service">
    <div class="jumbotron mt-4">
        <h2 class="text-center mb-3">Our Services</h2>
        <p>I have understood the information requirement of this Form (read along with the FATCA-CRS Instruction) and hereby
         confirm that the information  provided by me on this Form is true, correct and complete. I also confirm that I have
          read and understood the FATCA-CRS Terms and Conditions have understood the information requirement of this Form
          (read along with the FATCA-CRS Instruction) and hereby confirm that the information  provided by me on this Form is true,
           correct and complete. I also confirm that I have read and understood the FATCA-CRS Terms and Conditions</p>
    </div>
    </div>

    <!-- Start Icons-->
    <div class="container">
        <h1 class="text-center">Services</h1>
        <div class="row mt-4 text-center">
            <div class="col-sm-4 mt-4">
            <a href=""><i class="fas fa-tv fa-8x text-success"></i></a>
            <h4 class="mt-4">Electronic Application</h4>
            </div>
            <div class="col-sm-4 mt-4">
            <a href=""><i class="fas fa-sliders-h fa-8x text-primary"></i></a>
            <h4 class="mt-4">Preventive Maintenance</h4>
            </div>
            <div class="col-sm-4 mt-4">
            <a href=""><i class="fas fa-cogs fa-8x text-danger"></i></a>
            <h4 class="mt-4">Fault Repair</h4>
            </div>
        </div>
    </div>
    <!-- Start Registration Form-->
    <?php
    include('user_registration.php');
    ?>
    <!-- Happy customer-->
    <div class="container bg-success">
        <h2 class="text-center mt-5 text-white font-weight-bold">Happy Customer</h2>

        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
             </ol>
			<div class="carousel-inner">
				    <div class="carousel-item active col-lg-12 col-md-12 col-sm-12 p-4">
				        <div class="row">
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                        </div>
			        </div>
                    <div class="carousel-item col-lg-12 col-md-12 col-sm-12 p-4">
                        <div class="row">
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                        </div>
			        </div>
                    <div class="carousel-item col-lg-12 col-md-12 col-sm-12 p-4">
                        <div class="row">
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                            <div class="card-body col-lg-3 col-md-3 col-sm-3 text-center">
                                <img src="img/man2.jpg"  width="150px" style="border-radius:100px;" class="img-fluid" alt="">
                                <h4 class="card-title text-center">Rahul yadav</h4>
                                <small>provided by me on this Form is true,
                                correct and complete. I also confirm that I have read and unde</small>
                            </div>
                        </div>
			        </div>
            
			</div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
		</div>

          
       
    </div>
    
    <!-- Contact Us-->
    
   <?php
        include('contact_form.php');
   ?>

    <footer class="container-fluid bg-dark mt-5">
        <div class="row ">
            <div class="col-lg-6 text-center">
                <p class="font-weight-bold text-white mt-2">Follow Us: <i class="fab fa-youtube text-danger ml-2"></i>
                <i class="fab fa-facebook ml-2 text-primary"></i><i class="fab fa-twitter-square text-primary ml-2"></i>
                <i class="fab fa-google-plus-g text-danger ml-2"></i></p>
            </div>
            <div class="col-lg-6 text-center">
                <p class=" text-white mt-2 ml-5">Design By R.K. <small class="ml-5"><a href="admin/admin_login.php">Admin Login</a></small>
</p>
            </div>
        </div>
    </footer>
    <script src="js/script.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/all.min.js"></script>
</body>
</html>