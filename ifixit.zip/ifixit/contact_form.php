<div class="container" id="contact_us">
        <h1 class="text-center mt-4">Contact Us</h1>
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <form action="" method="post">
                <div class="form-group">
                    
                    <input type="text" name="rname" class="form-control" placeholder="Name">
                </div>
                <div class="form-group">
                   
                    <textarea name="carea" id="" cols="30" rows="5" class="form-control" placeholder="Subject"></textarea>
                </div>
                <div class="form-group">
                    
                    <input type="email" name="rname" class="form-control" placeholder="Enter Email">
                </div>
                <small>We will never share your email id with anyone</small>
                <div class="form-group">
                    <input type="submit" name="rsub" class="btn bg-primary mt-3 text-white" value="Submit" placeholder="Enter your name">
                </div>
                </form>
            </div>
        </div>
    </div>