<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <!--Bootstrap CSS-->
     <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap2.css">
    <link rel="stylesheet" href="css/bootstra.css">

    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css/all.min.css">

    <!--Style CSS-->
    <link rel="stylesheet" href="css/style.css">

</head>
    <script src="js/script.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/all.min.js"></script>
<body>
    
</body>
</html>