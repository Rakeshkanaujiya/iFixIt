1) Create database ifixit.
2) In footer part click on Admin login,
email id : admin@gmail.com.
password : 789456.
