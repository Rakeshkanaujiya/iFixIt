
   $(document).ready(function(){
    
    $(".alert").fadeOut(7000);
  
});