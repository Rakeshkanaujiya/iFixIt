<?php
   session_start();
   define('TITLE', 'Work Order');
   include('include/header.php');
   include('../dbConnection.php');
   if(isset($_SESSION['is_adminlogin']))
   {
       $aemail = $_SESSION['a_email'];
   }
   else{
       header('location:admin_login.php');
   }
?>

<div class=" col-lg-10 col-md-9 col-sm-12 col-xs-12" >
   <table class="table">
    <tr align='center'>
        <th>Req ID</th>
        <th>Request Info</th>
        <th>Name</th>
        <th>Address</th>
      
        <th>Mobile</th>
        <th>Technician</th>
        <th>Assign Date</th>
        <th>Action</th>
    </tr>
    <tr>
        <?php
            $q=mysqli_query($con, "select * from assign_work");

            while($arr=mysqli_fetch_array($q))
            {
                echo "
                    <tr align=''>
                       <td>$arr[0]</td>
                       <td>$arr[1]</td>
                       <td>$arr[3]</td>
                       <td>$arr[4],<br>$arr[6]</td>
                        <td>$arr[5]</td>
                       <td>$arr[11]</td>
                       <td>$arr[12]</td>
                       <td><form action='viewassignwork.php' method='post'>
                       <input type='hidden' name='id' value='$arr[1]'>
                       <div class='d-inline-flex'><button class='btn btn-warning mx-2' type='submit' name='view'><i class='fas fa-eye'></i></button>
                       <button class='btn btn-secondary' type='submit' name='delete'><i class='fas fa-trash-alt'></i></button></div>
                       </form>
                       </td>
                    </tr>
                ";
            }
        ?>
    </tr>
  
   </table>
</div>


<?php 
    include('include/footer.php');
?>