<?php
   session_start();
   define('TITLE', 'Work Order');
   include('include/header.php');
   include('../dbConnection.php');
   if(isset($_SESSION['is_adminlogin']))
   {
       $aemail = $_SESSION['a_email'];
   }
   else{
       header('location:admin_login.php');
   }
 ?>

<div class="col-lg-6">
<form action="" method="post" class="jumbotron mt-3 shadow p-5">
<a href="assets.php" style="margin-left:95%;"><i class="fas fa-arrow-circle-left fa-2x"></i></a>
            <p class="text-center"><b>Add new Product</b></p>
            
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Name</label><input type="text"  class="form-control" name="name" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">DOP</label><input type="date"  class="form-control" name="dop" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Available</label><input type="text"  class="form-control" name="avail" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Total</label><input type="text"  class="form-control" name="total" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Original Cost</label><input type="text"  class="form-control" name="og" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Selling Cost</label><input type="text"  class="form-control" name="sell" >
        </div>
        <div class="form-group text-center">
            <input type="submit" value="Submit" class="btn btn-block btn-danger" name="sub">
        </div>
        
    </form>
    <?php
        if(isset($_POST['sub']))
        {
               
                $name=$_POST['name'];
                $dop=$_POST['dop'];
                $avail=$_POST['avail'];
                $total=$_POST['total'];
                $og=$_POST['og'];
                $sell=$_POST['sell'];

                $q=mysqli_query($con, "INSERT INTO `asset`VALUES ('','$name','$dop','$avail','$total','$og','$sell')");
                if($q)
                {
                    echo "<script>alert('Asset Added Successfull')</script>";
                    header('location:assets.php');
                }
        }
    ?>
</div>

 <?php
   include('include/footer.php');
 ?>