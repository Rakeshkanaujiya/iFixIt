<?php
   session_start();
   define('TITLE', 'Work Order');
   include('include/header.php');
   include('../dbConnection.php');
   if(isset($_SESSION['is_adminlogin']))
   {
       $aemail = $_SESSION['a_email'];
   }
   else{
       header('location:admin_login.php');
   }
 ?>

 <div class="col-lg-9 col-md-9 col-sm-8">
    <div class="jumbotron col-lg-7 mt-3">
    
    <?php 
        if(isset($_POST['delete'])){
            $q=mysqli_query($con, "DELETE FROM `technician` WHERE e_id = {$_POST['id']}");
            if($q)
            {
                echo "<script>alert('Delete Successfull')</script>";
                header('location:technician.php');

            }
        }

        if(isset($_POST['edit']))
        {
            $q=mysqli_query($con, "select * from technician where e_id = {$_POST['id']}");
            $arr=mysqli_fetch_array($q);
        
    ?>
    <form action="" method="post">
    <a href="technician.php" style="margin-left:100%; margin-top:%;"><i class="fas fa-arrow-circle-left fa-2x"></i></a>

    <h3 class="text-center "><b>Update Technician Details</b></h3>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Emp ID</label><input type="text" value="<?php if(isset($arr[0])){echo $arr[0];} ?>" class="form-control" name="e_id" readonly>
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Technician Name</label><input type="text" value="<?php if(isset($arr[1])){echo $arr[1];} ?>" class="form-control" name="name" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Location</label><input type="text" value="<?php if(isset($arr[2])){echo $arr[2];} ?>" class="form-control" name="location" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Mobile</label><input type="text" value="<?php if(isset($arr[3])){echo $arr[3];} ?>" class="form-control" name="mobile" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Email</label><input type="text" value="<?php if(isset($arr[4])){echo $arr[4];} ?>" class="form-control" name="email" >
        </div>
        <div class="form-group text-center">
            <input type="submit" value="Update" class="btn btn-block btn-danger" name="e_sub">
        </div>
    </form>
    <?php
        }
        else{
            if(isset($_POST['e_sub']))
            {
                $eid=$_POST['e_id'];
                $name=$_POST['name'];
                $location=$_POST['location'];
                $mobile=$_POST['mobile'];
                $email=$_POST['email'];
              
                $q=mysqli_query($con, "UPDATE technician SET  e_name='$name', e_location='$location', e_mobile='$mobile', e_email='$email' where e_id = {$_POST['e_id']}");
                if($q)
                {
                    header('location:technician.php');
                    echo "<script>alert('Updated siccessfull')</script>";
                }
                else
                {
                    echo mysqli_error($con);                    
                }
            }
        }
    ?>
        
    </div>
 </div>

<?php
    include('include/footer.php');
?>