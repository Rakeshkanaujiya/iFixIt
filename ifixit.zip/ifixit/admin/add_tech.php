<?php
   session_start();
   define('TITLE', 'Add Tech');
   include('include/header.php');
   include('../dbConnection.php');
   if(isset($_SESSION['is_adminlogin'])){
       $aemail=$_SESSION['a_email'];
   }
   else
   {
       header('location:admin_login.php');
   }
 ?>
<div class="col-lg-6">
<form action="" method="post" class="jumbotron mt-3 shadow p-5">
<a href="technician.php" style="margin-left:95%;"><i class="fas fa-arrow-circle-left fa-2x"></i></a>
            <h2 class="text-center"><b>Add new Technician</b></h2>
            
        
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Technician Name</label><input type="text"  class="form-control" name="name" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Location</label><input type="text"  class="form-control" name="location" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Mobile</label><input type="text"  class="form-control" name="mobile" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Email</label><input type="text"  class="form-control" name="email" >
        </div>
        <div class="form-group text-center">
            <input type="submit" value="Submit" class="btn btn-block btn-danger" name="sub">
        </div>
    </form>
    <?php
        if(isset($_POST['sub']))
        {
          
                $name=$_POST['name'];
                $location=$_POST['location'];
                $mobile=$_POST['mobile'];
                $email=$_POST['email'];
              
                $q=mysqli_query($con, "INSERT INTO `technician` VALUES ('','$name','$location','$mobile','$email')");
                if($q)
                {
                    echo "<script>alert('Technician Added Successfull')</script>";
                    header('location:technician.php');
                }
        }
    ?>
</div>

 <?php 
    include('include/footer.php');
 ?>