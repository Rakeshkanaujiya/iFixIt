<?php
   session_start();
   define('TITLE', 'Work Order');
   include('include/header.php');
   include('../dbConnection.php');
   if(isset($_SESSION['is_adminlogin']))
   {
       $aemail = $_SESSION['a_email'];
   }
   else{
       header('location:admin_login.php');
   }


 ?>

<div class="col-lg-4">
   <?php 
       /*$q=mysqli_query($con, "select * from user_login");
        $row = mysqli_num_rows($q);*/

     $q=mysqli_query($con, "select * from request_info");

     
        while($arr = mysqli_fetch_array($q))
        {
          echo "<div class='card mt-3 mx-5'>
                    <div class='card-header'>Request ID: $arr[0] </div>
                        <div class='card-body'>
                            <h5 class='card-title'><b>Request Info : $arr[1]</b></h5>
                            <p class='card-text'> $arr[2] </p>
                            <p class='card-text'>Request Date : $arr[11] </p>
                            <form method='post'>
                            <div class='float-right'>
                            <input type='hidden' name='r_id' value='$arr[0]'>
                            <input type='submit' value='View' name='c_sub' class='btn btn-danger'>
                            <input type='submit' value='Close' name='close' class='btn btn-secondary'>
                            </div>
                         </form>
                    
                        </div>
                </div>";
                
        }
       
   ?>
   
</div>



<div class="mt-3 col-lg-6 ">
<?php 
    if(isset($_POST['c_sub']))
    {
    $q=mysqli_query($con, "select * from request_info where id = {$_POST['r_id']}");

    $arr = mysqli_fetch_array($q);
    }

    if(isset($_POST['close']))
    {
    $q=mysqli_query($con, "delete from request_info where id = {$_POST['r_id']}");
    if($q)
    {
        echo '<meta http-equiv="refresh" content="0; URL = ?closed" />';
    }

    }

    if(isset($_POST['a_sub']))
    {
        $r_id = $_POST['request'];
        $r_info = $_POST['request_info'];
        $desc = $_POST['desc'];
        $r_name = $_POST['r_name'];
        $add_line1 = $_POST['add_line1'];
        $add_line2 = $_POST['add_line2'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $zip = $_POST['zip'];
        $email = $_POST['email'];
        $mobile = $_POST['mobile'];
        $t_name = $_POST['t_name'];
        $a_date = $_POST['a_date'];
    $q=mysqli_query($con, "INSERT INTO `assign_work` VALUES ('','$r_id','$r_info','$desc','$r_name','$add_line1','$add_line2','$city','$state','$zip','$email','$mobile','$t_name','$a_date')");
    if($q)
    {
        echo '<script>alert("Assigned Successfull")</script>';
    }

    }
    
?>
<div class=" jumbotron mx-3">
<form action="" method="post"  class="">
   <div class="row"><!--1st Row -->
   <div class="form-group col-lg-12">
        <h3 class="text-center">Assign Work Order Request</h3>
    </div>
    <div class="form-group col-lg-12">
        <label for="">Request ID</label><input type="text" class="form-control" name="request" value="<?php if(isset($_POST['r_id'])){ echo $_POST['r_id']; } ?>" readonly>
    </div>
   <div class="form-group col-lg-12">
        <label for="">Request Info</label><input type="text" value=" <?php if(isset($arr[1])){ echo $arr[1];} ?> " class="form-control" name="request_info" placeholder="Request Info" required>
    </div>
    <div class="form-group col-lg-12">
        <label for="">Description</label><input type="text" value=" <?php if(isset($arr[2])){ echo $arr[2];} ?> " class="form-control" name="desc" placeholder="Write Description" required>
    </div>
    <div class="form-group col-lg-12">
        <label for="">Name</label><input type="text" value=" <?php if(isset($arr[3])){ echo $arr[3];} ?> " class="form-control" name="r_name" placeholder="Rahul" required>
    </div>
    <div class="row col-lg-12"><!--1sr Sub Row -->
        <div class="form-group col-lg-6">
            <label for="">Address Line 1</label><input type="text" value=" <?php if(isset($arr[4])){ echo $arr[4];} ?> " class="form-control" name="add_line1" placeholder="House no." required>
        </div>
        <div class="form-group col-lg-6">
            <label for="">Address Line 2</label><input type="text" value=" <?php if(isset($arr[5])){ echo $arr[5];} ?> " class="form-control" name="add_line2" placeholder="Railway colony" required>
        </div>
    </div>

    <div class="row col-lg-12"><!--2nd Sub Row -->
        <div class="form-group col-lg-5">
            <label for="">City</label><input type="text" value=" <?php if(isset($arr[6])){ echo $arr[6];} ?> " class="form-control" name="city" required>
        </div>
        <div class="form-group col-lg-4">
            <label for="">State</label><input type="text" value=" <?php if(isset($arr[7])){ echo $arr[7];} ?> " class="form-control" name="state" required>
        </div>
        <div class="form-group col-lg-3">
            <label for="">Zip</label><input type="text" value=" <?php if(isset($arr[8])){ echo $arr[8];} ?> " class="form-control" name="zip" required>
        </div>
    </div>
    <div class="row col-lg-12"><!--3rd Sub Row -->
        <div class="form-group col-lg-8">
            <label for="">Email</label><input type="email" value=" <?php if(isset($arr[9])){ echo $arr[9];} ?> " class="form-control" name="email" required>
        </div>
        <div class="form-group col-lg-4">
            <label for="">Mobile</label><input type="text" value=" <?php if(isset($arr[10])){ echo $arr[10];} ?> " class="form-control" name="mobile" required>
        </div>
    </div>
    <div class="row col-lg-12"><!--4rd Sub Row -->
        <div class="form-group col-lg-7">
            <label for="">Assign to Technician</label><input type="text" class="form-control" name="t_name" required>
        </div>
        <div class="form-group col-lg-5">
            <label for="">Date</label><input type="date" class="form-control" name="a_date" required>
        </div>
    </div>
    
    <div class=" col-lg-12 float-right">
        <input type="submit" value="Assign" class="btn btn-success" name="a_sub">
        <input type="reset" value="Reset" class="btn btn-secondary">
    </div>
   </div>

</form>

</div>
</div>

<?php 
    include('include/footer.php');
?>