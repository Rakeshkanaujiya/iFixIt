<?php
   session_start();
   define('TITLE', 'Work Order');
   include('include/header.php');
   include('../dbConnection.php');
   if(isset($_SESSION['is_adminlogin']))
   {
       $aemail = $_SESSION['a_email'];
   }
   else{
       header('location:admin_login.php');
   }
 ?>

 <div class="col-lg-9 col-md-9 col-sm-8">
    <div class="jumbotron col-lg-7 mt-3">
    
    <?php 
        if(isset($_POST['delete'])){
            $q=mysqli_query($con, "DELETE FROM `technician` WHERE e_id = {$_POST['id']}");
            if($q)
            {
                echo "<script>alert('Delete Successfull')</script>";
                header('location:technician.php');

            }
        }

        if(isset($_POST['edit']))
        {
            $q=mysqli_query($con, "select * from asset where a_id = {$_POST['a_id']}");
            $arr=mysqli_fetch_array($q);
        
    ?>
    <form action="" method="post">
    <a href="assets.php" style="margin-left:100%; margin-top:%;"><i class="fas fa-arrow-circle-left fa-2x"></i></a>

    <h3 class="text-center "><b>Update Product Details</b></h3>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Asset ID</label><input type="text" value="<?php if(isset($arr[0])){echo $arr[0];} ?>" class="form-control" name="a_id" readonly>
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Name</label><input type="text" value="<?php if(isset($arr[1])){echo $arr[1];} ?>" class="form-control" name="name" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">DOP</label><input type="date" value="<?php if(isset($arr[2])){echo $arr[2];} ?>" class="form-control" name="dop" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Available</label><input type="text" value="<?php if(isset($arr[3])){echo $arr[3];} ?>" class="form-control" name="avail" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Total</label><input type="text" value="<?php if(isset($arr[4])){echo $arr[4];} ?>" class="form-control" name="total" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Original Cost</label><input type="text" value="<?php if(isset($arr[5])){echo $arr[5];} ?>" class="form-control" name="og" >
        </div>
        <div class="form-group">
            <label for="Emp ID" class="fw-bold">Sell Cost</label><input type="text" value="<?php if(isset($arr[6])){echo $arr[6];} ?>" class="form-control" name="sell" >
        </div>
        <div class="form-group text-center">
            <input type="submit" value="Update" class="btn btn-block btn-danger" name="a_sub">
        </div>
    </form>
    <?php
        }
        else{
            if(isset($_POST['a_sub']))
            {
           
                $name=$_POST['name'];
                $dop=$_POST['dop'];
                $avail=$_POST['avail'];
                $total=$_POST['total'];
                $og=$_POST['og'];
                $sell=$_POST['sell'];
              
                $q=mysqli_query($con, "UPDATE `asset` SET `name`='$name',`dop`='$dop',`available`='$avail',`total`='$total',`og`='$og',`selling`='$sell' WHERE a_id = {$_POST['a_id']}");
                if($q)
                {
                   
                    echo "<script>alert('Updated siccessfull')</script>";
                    header('location:assets.php');
                }
                else
                {
                    echo mysqli_error($con);                    
                }
            }
        }
    ?>
        
    </div>
 </div>

<?php
    include('include/footer.php');
?>