<?php
    session_start();
    define('TITLE', 'Dashboard');
    include('../dbConnection.php');
    include('include/header.php');

   if(isset($_SESSION['is_adminlogin']))
   {
       $aemail = $_SESSION['a_email'];
   }
   else{
       header('location:admin_login.php');
   }

    $q=mysqli_query($con, "select * from user_login");
    $row = mysqli_num_rows($q);
    //$q=mysqli_query($con, "")

?>

<?php
     $r=mysqli_query($con, "select * from request_info");
     $re = mysqli_num_rows($r);
?>

<?php
    $t=mysqli_query($con, "select * from technician");
    $arr = mysqli_num_rows($t);
?>



<?php
    $a=mysqli_query($con, "select * from assign_work");
    $arr2 = mysqli_num_rows($a);
?>
        <div class="col-lg-10 col-md-10 col-sm-9">    
            <div class="row text-center mx-5">
                <div class="col-lg-4">
                    <div class="card text-white bg-danger mb-3" style="max-width:25rem;">
                        <div class="card-header">Requests Recived </div>
                        <div class="body">
                            <h1 class="card-title"><?php echo $re; ?></h1>
                            <a class="btn text-white" href="requests.php">View </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card text-white bg-warning mb-3" style="max-width:25rem;">
                        <div class="card-header">Assign Work</div>
                        <div class="body">
                            <h1 class="card-title"><?php echo $arr2; ?></h1>
                            <a class="btn text-white" href="work.php">View </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card text-white bg-info mb-3" style="max-width:25rem;">
                        <div class="card-header">No. of Technician</div>
                        <div class="body">
                            <h1 class="card-title"><?php echo $arr; ?></h1>
                            <a class="btn text-white" href="technician.php">View </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mx-5 mt-5  text-center">
                <p class="bg-dark text-white p-2"><b>List of Requester</b></p>
                    <table class="table table-hover col-lg-5">
                        <tr>
                            <th  style="text-align: center;">Requester ID</th>
                            <th  style="text-align: center;">Name</th>
                            <th  style="text-align: center;">Email</th>
                        </tr>
                        
                        <?php  while($nums = mysqli_fetch_array($q))
                                    {
                                        echo "<tr>
                                            <td> $nums[0] </td>
                                            
                                            <td> $nums[1] </td>
                                            <td> $nums[2] </td>
                                            </tr>";
                                    } 
                        ?>
                        </tr>
                    </table>
                     
            </div>

        </div>
<?php 
    include('include/footer.php');
?>