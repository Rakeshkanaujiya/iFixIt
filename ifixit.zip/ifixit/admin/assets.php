<?php
   session_start();
   define('TITLE', 'Work Order');
   include('include/header.php');
   include('../dbConnection.php');
   if(isset($_SESSION['is_adminlogin']))
   {
       $aemail = $_SESSION['a_email'];
   }
   else{
       header('location:admin_login.php');
   }
 ?>

<div class="col-lg-10">
   <h3 class="text-center bg-dark text-white mx-5 mb-4"><b>List of asset's</b></h3>
   <div class="mx-5">
        <table class="table">
            <tr>
                <th>Product ID</th>
                <th>Name</th>
                <th>DOP</th>
                <th>Available</th>
                <th>Total</th>
                <th>Original Cost Each</th>
                <th>Selling Cost Each</th>
                <th>Action</th>
            </tr>
            <?php
                $q=mysqli_query($con, "select * from asset");
                $arr=mysqli_num_rows($q);
              

                while($arr=mysqli_fetch_array($q))
                {
                    echo "<tr>
                            <td>$arr[0]</td>
                            <td>$arr[1]</td>
                            <td>$arr[2]</td>
                            <td>$arr[3]</td>
                            <td>$arr[4]</td>
                            <td>$arr[5]</td>
                            <td>$arr[6]</td>
                            
                            <td>
                                <form action='asset_edit.php' method='post'>
                                    <div class='d-inline-flex'>
                                        <input type='hidden' name='a_id' value='$arr[0]'>
                                        <button type='submit' name='edit' class='btn btn-danger mx-2'><i class='fas fa-pen'></i></button>
                                        <button type='submit' name='delete' class='btn btn-secondary mx-2'><i class='fas fa-trash'></i></button>
                                    </div>
                                </form>
                            </td>
                    </tr>";
                }
            ?>
            
        </table>
   </div>
   <form action="asset_add.php"  method='post'>
    <div class="row justify-content-end mx-5" style="margin-top:20%;">
        <button type="submit" name="add" class="btn btn-warning"><i class="fas fa-plus-square fa-2x"></i></button>
    </div>
   </form>
</div>
<?php 
    include('include/footer.php');
?>