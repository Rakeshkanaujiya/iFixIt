<?php
   session_start();
   define('TITLE', 'Work Order');
   include('include/header.php');
   include('../dbConnection.php');
   if(isset($_SESSION['is_adminlogin']))
   {
       $aemail = $_SESSION['a_email'];
   }
   else{
       header('location:admin_login.php');
   }
 ?>
<script>
function myFunction() {
  confirm("You want to delete this Technician");
}
</script>
<div class="col-lg-10">
   <h3 class="text-center bg-dark text-white mx-5 mb-5"><b>List of Technician</b></h3>
   <div class="mx-5">
        <table class="table">
            <tr>
                <th>Emp ID</th>
                <th>Name</th>
                <th>Location</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
            
                <?php 
                    $q=mysqli_query($con,"select * from technician");
                    while($arr=mysqli_fetch_array($q))
                    {
                        echo "<tr>
                                <td>$arr[0]</td>
                                <td>$arr[1]</td>
                                <td>$arr[2]</td>
                                <td>$arr[3]</td>
                                <td>$arr[4]</td>
                                <td>
                                    <form action='tech_edit.php' method='post'>
                                        <div class='d-inline-flex'>
                                            <input type='hidden' name='id' value='$arr[0]'>
                                            <button type='submit' name='edit' class='btn btn-danger mx-2'><i class='fas fa-pen'></i></button>
                                            <button type='submit' name='delete' class='btn btn-secondary'><i class='fas fa-trash'></i></button>
                                        </div>
                                    </form>
                                </td>
                        </tr>";
                    }
                ?>
            
        </table>
   </div>
   <form action="add_tech.php"  method='post'>
    <div class="row justify-content-end mx-5" style="margin-top:20%;">
        <button type="submit" name="add" class="btn btn-warning"><i class="fas fa-plus-square fa-2x"></i></button>
    </div>
   </form>
</div>
<?php 
    include('include/footer.php');
?>