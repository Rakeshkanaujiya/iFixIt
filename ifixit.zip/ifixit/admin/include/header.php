<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo TITLE ?></title>
    <!--Bootstrap CSS-->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/bootstrap4.css">
    <link rel="stylesheet" href="../css/bootstrap3.css">



    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="../css/all.min.css">

    <!--Style CSS-->
    <link rel="stylesheet" href="../css/style.css">

    <!--Google font-->
    <title>ifixit</title>
</head>
<!--Top Navbar-->
<nav id="navbar2" class="navbar navbar-expand-sm fixed-top bg-success flex-md-nowrap p-0 shadow">
    <a href="index.php" class="navbar-brand font-weight-bold text-white ml-4"><font size="6">iFixIt</font></a>
</nav>
<!--Start Cntainer-->
    <div class="container-fluid ">
        <div class="row" > <!-- Start row -->
        <div class="sidebar-sticky col-lg-2 col-md-3 col-sm-3 col-xs-4 mt-3">
            <nav class="bg-light sidebar" id="sidebar">
                <div>
                <ul class="nav flex-column">
                    <li  class="active"><a href="./dashboard.php"><i class="fas fa-tachometer-alt mr-2"></i>Dashboard</a></li></li>
                    <li><a href="./work.php"><i class="fab fa-accessible-icon mr-2"></i>Work Order</a></li>
                    <li><a href="./requests.php"><i class="fas fa-align-center mr-2"></i>Requests</a></li>
                    <li><a href="./assets.php" class="nav-link"><i class="fas fa-database mr-2"></i>Assets</a></li>
                    <li><a href="./technician.php"><i class="fas fa-user mr-2"></i>Technician</a></li></li>
                    <li><a href="../logout.php" class="nav-link"><i class="fas fa-sign-out-alt mr-2"></i>Logout</a></li>
                    </ul>
                </div>
            </nav><!--Sidebar End-->
        </div>
          