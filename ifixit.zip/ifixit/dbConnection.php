<?php
    $con = mysqli_connect("localhost", "root", "", "ifixit");
    /*
    if($con->connect_error){
        die("Connection failed");
    }
    else{
        echo "Connect";
    }*/
    
?>